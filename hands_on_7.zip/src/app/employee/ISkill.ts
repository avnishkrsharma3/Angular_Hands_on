

export interface ISkill {
    skillArray : string [];
}