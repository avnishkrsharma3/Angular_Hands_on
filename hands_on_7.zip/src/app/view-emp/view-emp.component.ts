import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'view-emp',
  templateUrl: './view-emp.component.html',
  styleUrls: ['./view-emp.component.css']
})
export class ViewEmpComponent implements OnInit{
  ngOnInit(): void {
   // throw new Error('Method not implemented.');
  }

}
