
export interface IDepartment {
    id : number,
    name: string
}