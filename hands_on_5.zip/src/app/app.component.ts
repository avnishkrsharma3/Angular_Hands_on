import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'hands_on_3 and hands_on_4';
  // hands_on_3 
  favoriteMovie = 'Lord of the Rings'
}
