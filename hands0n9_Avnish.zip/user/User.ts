

export interface user {
    id:number,
    email:string,
    firstname:string,
    lastname:string,
    avatar:string
}