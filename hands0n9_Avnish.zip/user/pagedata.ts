import { user } from "./User";

export interface pagedata {
    data:user[];
}